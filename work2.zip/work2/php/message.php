<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../css/message.css" rel="stylesheet" />
	<title>Checkout</title>
</head>
<body>
<center>
<div class="word">
<h1>Your Cart not any product</h1>

<p>You can go to product listing to add product</p>

<a href="c_product.php">Back to shopping</a>
</div>
</center>
</body>
</html>

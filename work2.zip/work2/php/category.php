 <html>
        <head>
	        <meta charset="utf-8" />
	            <meta http-equiv="X-UA-Compatible" content="IE=edge" />
	                <meta name="viewport" content="width=device-width, initial-scale=1.0">
	                    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
	                        <title>Customer Products</title>
	                    <link href="../css/c_product.css" rel="stylesheet" />
                </head>
            <body>
	    <div class="link_product">
	<div class="box0">
<div class="img-box">
	<a href="product.php?category=1">
		<img src="../img/yonex racket.jpeg" alt="Man shoes" class="cat">
		    </a>
			    </div>
                    <div class="detail-box">
                        <h5><a href="product.php?category=1">Flower</a></h5>
					        </div>
				        </div>
	                <div class="box0">
                <div class="img-box">
			<a href="product.php?category=2">
		<img src="../img/Shoes.jpeg" alt="Woman_shoes" class="cat">
	</a>
</div>
    <div class="detail-box">
        <h5><a href="product.php?category=2">Cake</a></h5>
            </div>            
                </div>
	                <div class="box0">
                        <div class="img-box">
			                <a href="product.php?category=3">
			            <img src="../img/yonex clothing.jpeg" alt="" class="cat"> 
				    </a>
                </div>
            <div class="detail-box">
        <h5><a href="product.php?category=3">Chocolate</a></h5>
    </div>
</div>
	<div class="box0">
        <div class="img-box">
			<a href="product.php?category=4">
                <img src="../img/bag.jpeg" alt="" class="cat">
			        </a>
                        </div>
                            <div class="detail-box">
                        <h5>
                    <a href="product.php?category=4">Bear</a>
                </h5>
            </div>
        </div>
    </div><hr>
	</body>
	</html>
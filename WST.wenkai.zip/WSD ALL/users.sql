-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2023 at 10:25 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `UserID` varchar(10) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `PhoneNumber` varchar(12) NOT NULL,
  `Gender` char(1) NOT NULL,
  `UserPassword` varchar(20) NOT NULL,
  `AccType` char(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`UserID`, `Username`, `Email`, `PhoneNumber`, `Gender`, `UserPassword`, `AccType`) VALUES
('ADMIN001', 'Yip', 'yip@gmail.my', '1100112233 ', 'M', 'password012', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `Title` varchar(50) NOT NULL,
  `Image` varchar(20) NOT NULL,
  `AnnouncementDesc` varchar(500) NOT NULL,
  `Dates` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`Title`, `Image`, `AnnouncementDesc`, `Dates`) VALUES
('New Couch', 'p1', 'Welcome Our New Coach !!!-----We are pleased to announce that Malaysian Development Basketball League MVP Qiu Jiahao will serve as our TARUMT basketball coach.-----Jiahao won the national championship in the Malaysian Development Basketball League last season, and recently represented Malaysia in the FIBA 3X3 Asia Cup, and brought a wealth of game experience to the club.-----He is very qualified to serve as tarumt\'s basketball academy coach.', '2023-04-20');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `Title` varchar(50) NOT NULL,
  `image` varchar(30) NOT NULL,
  `EventDescription` varchar(1000) NOT NULL,
  `user` varchar(10) NOT NULL,
  `registerform` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`Title`, `image`, `EventDescription`, `user`, `registerform`) VALUES
('TARUMT CUP 5 vs 5 (Perak Branch)', 'p5', 'Tarumt Cup are divided Male and Female. ----- One Team at least 8 members(Must is TARUMT Student). ---- At least 10 teams must be raised before the competition can be held.----\r\n                                                    ----- Prize -----\r\nThe champion can get RM2500 cash + champion medal + soft skill mark (30 points per person).-----The runner-up can get RM1500 cash + runner-up medal + soft skill mark (20 points per person).-----The third runner-up can get RM500 cash + third runner-up medal + soft skill mark (10 points per person).-----If you are interested, please register and fill in your information.', 'USER0001', 'register(A) form'),
('TARUMT 3 ON 3 (Perak Branch)', 'p6', 'Tarumt 3ON3 are divided Male and Female. -----One team at least 3 members and at most 4 members(Must is TARUMT Student). -----The 3ON3 competition will be held on May 27, 2023.----------Prize</h4>----------The champion can get RM500 cash + champion medal + soft skill mark (30 points per person).-----The runner-up can get RM300 cash + runner-up medal + soft skill mark (20 points per person).-----\r\nThe third runner-up can get RM150 cash + third runner-up medal + soft skill mark (10 points per person).-----If you are interested, please register and fill in your information.', 'ADMIN001', 'register(B) form');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` varchar(10) NOT NULL,
  `AccType` varchar(6) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `PhoneNumber` int(11) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `Gender` char(1) NOT NULL,
  `UserPassword` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `AccType`, `Username`, `PhoneNumber`, `Email`, `Gender`, `UserPassword`) VALUES
('USER0001', 'client', 'Thum Weng Yip', 1111223344, 'wengyip@gmail.com', 'M', 'password123'),
('USER0002', 'client', 'Tang Li Heng', 1122334455, 'liheng@gmail.com', 'M', 'password234'),
('USER0003', 'client', 'Goh Wen Kai', 1133445566, 'wenkai@gmail.com', 'M', 'password345'),
('USER0004', 'client', 'Sak Zu Weng', 1144556677, 'zuweng@gmail.com', 'M', 'password456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

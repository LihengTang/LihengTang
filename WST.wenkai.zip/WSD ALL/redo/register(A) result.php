<?php
function detectInputError(){
	
	global $Player1,$Player2,$Player3,$Player4,$Player5,$Player6,$Player7,$Player8,$ID,$gender,$phone;
	
	$error=array();
        
	if($Player1==null){
		$error['Player1']='Please enter your name 1.';
	}
	else if(!preg_match('/^[A-Za-z @,\'\.\-\/]+$/', $Player1)){
		$error['Player1']='There are invalid characters in your name.';
	}
	else if(strlen($Player1) > 30)
		$error['Player1']='Name must be less than 30 characters.';
	     
	if($Player2==null){
		$error['Player2']='Please enter your name 2.';
	}
	else if(!preg_match('/^[A-Za-z @,\'\.\-\/]+$/', $Player2)){
		$error['Player2']='There are invalid characters in your name.';
	}
	else if(strlen($Player2) > 30)
		$error['Player2']='Name must be less than 30 characters.';
	     
	if($Player3==null){
		$error['Player3']='Please enter your name 3.';
	}
	else if(!preg_match('/^[A-Za-z @,\'\.\-\/]+$/', $Player3)){
		$error['Player3']='There are invalid characters in your name.';
	}
	else if(strlen($Player3) > 30)
		$error['Player3']='Name must be less than 30 characters.';
	     
	if($Player4==null){
		$error['Player4']='Please enter your name 4.';
	}
	else if(!preg_match('/^[A-Za-z @,\'\.\-\/]+$/', $Player4)){
		$error['Player4']='There are invalid characters in your name.';
	}
	else if(strlen($Player4) > 30)
		$error['Player4']='Name must be less than 30 characters.';
	
	if($Player5==null){
		$error['Player5']='Please enter your name 5.';
	}
	else if(!preg_match('/^[A-Za-z @,\'\.\-\/]+$/', $Player5)){
		$error['Player5']='There are invalid characters in your name.';
	}
	else if(strlen($Player5) > 30)
		$error['Player5']='Name must be less than 30 characters.';
	
	if($Player6==null){
		$error['Player6']='Please enter your name 6.';
	}
	else if(!preg_match('/^[A-Za-z @,\'\.\-\/]+$/', $Player6)){
		$error['Player6']='There are invalid characters in your name.';
	}
	else if(strlen($Player6) > 30)
		$error['Player6']='Name must be less than 30 characters.';
	
	if($Player7==null){
		$error['Player7']='Please enter your name 7.';
	}
	else if(!preg_match('/^[A-Za-z @,\'\.\-\/]+$/', $Player7)){
		$error['Player7']='There are invalid characters in your name.';
	}
	else if(strlen($Player7) > 30)
		$error['Player7']='Name must be less than 30 characters.';
	
	if($Player8==null){
		$error['Player8']='Please enter your name 8.';
	}
	else if(!preg_match('/^[A-Za-z @,\'\.\-\/]+$/', $Player8)){
		$error['Player8']='There are invalid characters in your name.';
	}
	else if(strlen($Player8) > 30)
		$error['Player8']='Name must be less than 30 characters.';
        
	if($ID==null){
		$error['ID']='Please enter your Student ID.';
	}

	
	if($gender==null)
		$error['gender']='Please select your gender.';
	else if(!preg_match('/^[MF]$/', $gender))
		$error['gender']='Gender can only be either M or F.';
        
	if($phone==null){
		$error['phone']='Please enter your phone number.';
	}
	else if(!preg_match("/^[0][1]\d{1}\-\d*$/",$phone)){
		$error['phone']="Please enter numeric value that start with 01 and dash "; 
	}
	else if(strlen($phone)!=11 && strlen($phone)!=12){
		$error['phone']="Please enter 10 or 11 digit only"; 
	}
	
	return $error;
}
?>

<html>
<head>
<form method="post" action="event10.php"> 
<style>
.error{
	color:red;
}
button#exit{
	width:20%;
}
</style>
</head>

<body>
<?php

if(isset($_POST['submit'])){
	
	if(isset($_POST['gender'])){
		$gender=$_POST['gender'];
	}
	
	$Player1=trim($_POST['Player1']);
	
	$Player2=trim($_POST['Player2']);
		
	$Player3=trim($_POST['Player3']);
			
	$Player4=trim($_POST['Player4']);
	
	$Player5=trim($_POST['Player5']);
	
	$Player6=trim($_POST['Player6']);
	
	$Player7=trim($_POST['Player7']);
	
	$Player8=trim($_POST['Player8']);
	
	$ID=trim($_POST['ID']);
	
	$phone=trim($_POST['phone']);
	
        
	$error=detectInputError();
	if(empty($error)){
		echo "<h1>Register Success!!!Thanks for register the TARUMT CUP 5V5.</h1>";
		if($gender='M')
			echo "<h3>Mr. $Player1, Mr. $Player2, Mr. $Player3, Mr. $Player4, Mr. $Player5, Mr. $Player6, Mr. $Player7, 
		and Mr. $Player8.</h3>";
		 
		else
			echo "<h3>Ms. $Player1, Ms. $Player2,Ms. $Player3 and Ms. $Player4.</h3>";
	}
	else{
		printf('
		<h1>OOPS... There are the information errors  !!!</h1>
		<ul><li class="error">%s</li></ul>
		<p><a href="javascript:history.back()">Back</a></p>
		',implode('</li><li class="error">',$error));
	}
}

?>
<form>
<button class="exit" value="Back To Event Page.">
</form>
</body>

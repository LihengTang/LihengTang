<html>
<head>
	<link rel="stylesheet" href="headerfooter.css"/>
    <link rel="stylesheet" href="about_us.css"/>
    <link rel="stylesheet" href="latest.css"/>
	<title>Add Events</title>
</head>
<body>
<?php require_once('connect.php');?>
<?php

if(isset($_POST['submit'])){
$title= $_POST['title'];
$des= $_POST['des'];
}
$user ='99';
if(isset($_FILES['img'])){
$image= $_FILES['img'];
$imgname= $_FILES['img']['name'];
$imgerror= $_FILES['img']['error'];
$imgsize= $_FILES['img']['size'];
$imgfile = 'htdocs'.$imgname;
$imgtemp = $_FILES['img']['tmp_name'];
$imgtype = $_FILES['img']['type'];
}

$error = detectInputError();


function detectInputError(){

global $title, $des, $imgerror, $imgsize, $imgtype;
$error = array();



if(isset($_POST['submit'])){
if($title ==NULL){$error['title'] =' Key in the title ';}
if($des == NULL){$error['des'] ='Key in the describe ';}

}
if(isset($_FILES['img'])){
if($imgsize >12500000	){$error['img'] = 'File too large';}
if($imgtype!=NULL){if($imgtype != 'image/png'&& $imgtype !='image/jpeg'&&$imgtype !='image/jpg'){$error['imgtyp'] = 'Not an image';}}
}

return $error;
}

if(isset($_POST['submit'])){
if($error !=null){echo"<h1>OPSS... There are some Error</h1>";
   echo"<ul>";
   foreach($error as $value){
   printf("<li>$value</li>");}
   echo"</ul>";}
else{
 
move_uploaded_file($imgtemp,$imgfile);

$q = "INSERT INTO 'event' VALUES('$user','$title', '$des', 'htdocs$imgname')";
$r = @mysqli_query($connect, $q); }   



mysqli_close($connect);}
?>
<style>
form{
width:100mm;	
margin:auto;
background-color:white;
border:outset 5px orange;
}
textarea{resize:none;}
h1{
text-align:center;
font-size:5em;
font-family:sans-serif;
border:double 10px orange;
width:130mm;
margin:auto;
background-color:white;
}
html{
	background-color:#F74F36;
}
body{
	background-color:#FFD07D;
	width:330mm;
	margin:auto;
	border:groove 10px #FFD07D;
}
</style>
<div class="right"></div>
    <?php    
        include('header(admin).php');
    ?>
</div>
<br>
<div class="left">
<br>
<h1>Post Event</h1><br><br>
<form action="addevents.php" method="post" enctype="multipart/form-data">
<fieldset><br>
Title: <input name="title" type="text" value="<?php if(isset($_POST['submit'])) echo $title;?>" ><br><br>
Description: <textarea name="des" rows="5" cols="40" value="<?php echo $des;?> "></textarea><br><br>
Image: <input name="img" type="file" value="<?phpecho $imagename;?> "><br><br>
<button type="submit" name="submit">submit</button>
<button type="reset">reset</button><br>
</fieldset>
</form>
</div class="left">
<div class="footer">
    <p>TARUMT Basketball Society</p>
</div>
</body>
</html>


<?php
require_once('connect.php');

$student_id = $_REQUEST['id'];
$student_name = "";
$gender = "";
$program = "";

if(!empty($_POST))
{
	$student_id = strtoupper(trim($_POST['id']));
    $q = "DELETE FROM user WHERE UserID ='$student_id'";
    $r = mysqli_query($connect,$q);
    if($r)
    {
        echo"The Student Has Been Deleted Successfully";
    }
    else
    {
        echo"An ErroR Has Occured.The Student Cannot Be Deleted Successfully";
    }
    $student_id = "";
    $student_name = "";
    $gender = "";
    $program = "";
}
else
{
    $q = "SELECT * FROM user WHERE UserID = '$student_id'";
    $r = mysqli_query($connect,$q);
    if(mysqli_num_rows($r) == 1)
    {   
        $row = mysqli_fetch_array($r);
        $student_id = $row['UserID'];
        $student_name = $row['Username'];
        $phonenumber = $row['PhoneNumber'];
    }
    mysqli_free_result($r);
}

mysqli_close($connect);
?>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="headerfooter.css"/>
        <link rel="stylesheet" href="latest.css"/>
        <title>Delete User</title>
    </head>
    <body>
    <?php    
        include('header(admin).php');
    ?>
    <div class="left">
        <div class ="event">
        <h1>Delete User</h1>
        <fieldset>
                <form action="delete.php" method="post">
                    <div class="z">
                        <label>Student ID: </label>
                        <td colspan="2">
                            <?php echo $student_id;?>
                            <input type="hidden" name="id" value="<?php echo $student_id;?>"maxlength="10"/>
                        </td>
                    </div>
                    </br>
                    <div class="z">
                        <label>Student Name: </label>
                        <td colspan="2"><?php echo $student_name;?></td>
                        <input type="hidden" name="studentname" value="<?php echo $student_name;?>"/>
                    </div>
                </br>
                    <div class="z">
                        <label>Phone Number: </label>
                        <td colspan="2"><?php echo $phonenumber;?></td>
                        <input type="hidden" name="phonenumber" value="<?php echo $phonenumber;?>"/>
                    </div>  
                    </br>
                    <p>Do you really want to delete this User?</p>
                    </br>
                    <button type="submit"name="delete">Delete</button>
                    <button type="button"onclick="location='userinfo.php'">Back</button>
                </form>
        </fieldset>
        </div>
    </div>
    <body>
</html>
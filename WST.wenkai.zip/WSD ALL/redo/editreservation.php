<?php
require_once('con1.php');

$customer_id = $_REQUEST['id'];
$customer_name = "";
$gender = "";
$email = "";
$phone = "";
$error = "";

if(!empty($_POST)) {
	$customer_id = strtoupper(trim($_POST['id']));
	
	$customer_name = trim($_POST['customer_name']);
	if (isset($_POST['gender'])) {
		$gender = $_POST['gender'];
	}
	$email = $_POST['email'];
	
	$phone = $_POST['phone'];
	
	$error = array();
	
	if($customer_id ==null) {
		$error['customer_id'] = 'Please enter the Customer ID.';
	}
	if($customer_name == null) {
		$error['customer_name'] = 'Please enter the customer Name.';
	}
	if(!isset($_POST['gender'])) {
		$error['gender'] = 'Please enter the Gender.';
	}
	if($email == null) {
		$error['email'] = 'Please enter the Email.';
	}
	if($phone == null) {
		$error['phone'] = 'Please enter the Phone.';
	}
	if (empty($error)) {
		$q = "UPDATE customer SET customer_name = '$customer_name',
		gender = '$gender',email = '$email',phone = '$phone' WHERE customer_id = '$customer_id'";
		$r = mysqli_query($dbc, $q);
		
		if ($r) {
			echo "<p>The customer has been update successful.</p>";
		} else {
			echo "<p>The customer cannot be update succeddfully.</p>";
		}
		
	} else {
		echo "<ul>";
		foreach ($error as $value) {
			echo "<li>$value</li>";
		}
		echo "</ul>";
	}
}
$q = "SELECT * FROM customer WHERE customer_id = '$customer_id'";
$r = mysqli_query($dbc, $q);

if (mysqli_num_rows($r) == 1) {
	$row = mysqli_fetch_array($r);
	$customer_id = $row['customer_id'];
	$customer_name = $row['customer_name'];
	$gender = $row['gender'];
	$email = $row['email'];
	$phone = $row['phone'];
}

mysqli_free_result($r);

mysqli_close($dbc);

?>



<html>
 <head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="edit-customer.css"/>
	
 </head>
 <style>
 body {
}
.btn {
  border: 2px solid black;
  background-color: white;
  color: black;
  padding: 14px 28px;
  font-size: 16px;
  cursor: pointer;
}
</style>
<body>
<br>
<center>
<h2>Edit Reservation</h2>
<form action="editreservation.php" method="post">
<p>
[ <a href="reservationinfo.php">Reservation Info</a> ]
</p>
<table border="1">
		<tr>
					<td>Customer ID:</td>
			<td>
				<?php echo $customer_id; ?>
				<input type="hidden" name="id" value="<?php echo $customer_id; ?>" />
			</td>
				</tr>
				<tr>
					<td>Customer Name:</td>
					<td><input type="text" name="customer_name"
					value="<?php echo $customer_name; ?>" /></td>
				</tr>
				<tr>
			<td>Gender:</td>
			<td>
				Female<input type="radio" name="gender" value="F"
				<?php if ($gender == 'F') echo "checked='checked'"; ?> />
				Male<input type="radio" name="gender" value="M"
				<?php if ($gender == 'M') echo "checked='checked'"; ?> />
			</td>
		</tr>
				<tr>
					<td>Email:</td>
					<td><input type="text" name="email"
					value="<?php echo $email; ?>" /></td>
				</tr>
		        <tr>
					<td>Phone:</td>
					<td><input type="text" name="phone"
					value="<?php echo $phone; ?>" /></td>
				</tr>
	</table>
	<input type="submit" name="update" value="Update"/>
	<a href="reservationinfo.php">
		<input type="button" name="cancel" value="Cancel">
	</a>
	
	<p>
</p>
</form>
</center>
</div>
 </body>
</html>

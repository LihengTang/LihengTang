<?php
require_once('con.php');
$staff_id = $_REQUEST['staff_id'];
$staff_name = "";
$gender = "";
$job_position = "";
$message = "";

if(!empty($_POST)) {
	$staff_id = strtoupper(trim($_POST['staff_id']));
	
	$q = "DELETE FROM admin WHERE staff_id = '$staff_id'";
	$r = mysqli_query($condb, $q);
		
	if ($r) {
		echo "The staff has been deleted successfully.";
	} else {
		echo "The staff cannot be deleted successfully.";
	}
	
	$staff_id = "";
	$staff_name = "";
	$gender = "";
	$job_position = "";
}else{
	$q = "SELECT * FROM admin WHERE staff_id = '$staff_id'";
	$r = mysqli_query($condb, $q);

	if (mysqli_num_rows($r) == 1) {
		$row = mysqli_fetch_array($r);
		$staff_id = $row['staff_id'];
		$staff_name = $row['staff_name'];
		$gender = $row['gender'];
		$job_position = $row['job_position'];
	}
	mysqli_free_result($r);
}

mysqli_close($condb);

?>

<!DOCTYPE html>
<html>
<head>
<title>Delete Staff</title>
	<meta charset="UTF-8">
    <link rel="stylesheet" href="delete_leader.css"/>
</head>
<style>
	.($r){
		color:red;
	}
</style>
<body>

<h1>Delete Student</h1>
<?php
if($message){
	echo "<p>".$message."</p>";
}
if (empty($_POST))
?>
<form action="delete_leader.php" method="post">
<p>Are you sure you want to delete the following staff?

<input type="submit" name="delete" value="Yes"/>
	<a href="list_leader.php">
		<input type="button" name="cancel" value="No">
		<input type="button" name="cancel" value="Back">
	</a></p>


	<table border="1">
		<tr>
			<th>Staff ID:</th>
			<td>
				<?php echo $staff_id; ?>
				<input type="hidden" name="staff_id" value="<?php echo $staff_id; ?>" maxlength="10" />
			</td>
		</tr>
		<tr>
			<th>Staff Name:</th>
			<td><?php echo $staff_name; ?></td>
		</tr>
		<tr>
			<th>Gender:</th>
			<td><?php if ($gender) echo $gender; ?></td>
		</tr>
		<tr>
			<th>Job_Position:</th>
			<td><?php if ($job_position) echo $job_position; ?></td>
		</tr>
	</table>
	
</form>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="register2.css"/>
  <link rel="stylesheet" href="headerfooter.css"/>
  <link rel="stylesheet" href="latest.css"/>
  <form method="post" action="register(B) result.php"> 
  <title>Register TARUMT 3ON3</title>
</head>
<body>
  <div class= "right">
    <?php
      include('header.php');
    ?>
  </div>
  <div class="left">
    <header>
       <form method="post" action="register 5v5.php"> 
        <div class="a">
          <h1>REGISTRATION FORM of TARUMT  3on3</h1>
          <img id="R1" src="p8.jpg" width="850px" height="550px"  alt=""/>
        </div>
    </header>
    </br>
    <fieldset>
      <h2>Players Information</h2>
        <br>
            <div class="g">
               <td>Player1 Name:</td>
			<td colspan="2"><input type="text" name="Player1"></td>
            </br>       
                
               <td>Student ID:</td>
			<td colspan="2"><input type="number_format" name="ID"></td>
    </br>
    </br>        
               <td>Player2 Name:</td>
			<td colspan="2"><input type="text" name="Player2"></td>
             </br>    
                 
                <td>Student ID:</td>
			<td colspan="2"><input type="text" name="ID"></td>
    </br>
    </br>            
                <td>Player3 Name:</td>
			<td colspan="2"><input type="text" name="Player3"></td>
             </br>     
                
               <td>Student ID:</td>
			<td colspan="2"><input type="text" name="ID"></td>
    </br>
    </br>            
              <td>Player4 Name:</td>
			<td colspan="2"><input type="text" name="Player4"></td>      
              
               <td>Student ID:</td>
			<td colspan="2"><input type="number_format" name="ID"></td>
			
			</br>
			</br>
			<td>Gender:</td>
            <td>
                <input type="radio" name="gender" value="M"/><label>Male</label>
                <input type="radio" name="gender" value="F"/><label>Female<label>
            </td>
            <tr>
			
			</br>
			</br>
                <td>Mobile Phone:</td>
                <td colspan="2"><input type="number_format" name="phone"></td>
            </tr>
            </br>
            </br>
            <td><input type="submit" value="submit" name="submit">&nbsp;<input type="reset" value="reset"></td>
        </div>
  </form>
  </fieldset>
  </div class="left">
  <div class="footer">
        <p>TARUMT Basketball Society</p>
    </div>
  </body>
 </html>

<html>
<head>
	<meta charset="UTF-8">
    <link rel="stylesheet" href="about_us.css"/>
    <title>About Us</title>

</head>
<body>
		
			<h1>About Us</h1>
		
		<div id="about">
			<img src="p10.jpg" width="850px" height="350px" alt="alt"/>
		</div>
		
		<div id="word">
			<p>The TARUMT Basketball Society is a group of individuals who share a common passion for basketball. 
			   The society is dedicated to promoting the sport, providing a platform for basketball players of all 
			   levels to come together and engage in the game, and developing skills and sportsmanship.
			</p>
			
			<p>The society was established with the goal of creating a community of individuals who love basketball 
			   and want to play it regularly. Members of the society come from diverse backgrounds, including students, 
			   working professionals, and basketball enthusiasts from various parts of the country.
			</P>
			
			<p>The society offers a wide range of activities, including regular basketball games, training sessions, 
			   and tournaments. Members are encouraged to participate in all activities, regardless of their skill level, 
			   as the society is focused on helping members improve their skills and develop their game.
			</P>
			
			<p>In addition to promoting the sport, the society places a strong emphasis on teamwork, sportsmanship, 
			   and community. Members are encouraged to work together as a team, support each other, and help build a strong 
			   and vibrant community around the sport.
			</p>
			
			<p>Overall, the TARUMT Basketball Society is a dynamic and passionate group of individuals who share a love 
			for basketball. The society provides an excellent platform for individuals to engage with the sport, develop 
			their skills, and build lasting relationships with like-minded individuals.
			</p>
		</div>
</body>
</html>
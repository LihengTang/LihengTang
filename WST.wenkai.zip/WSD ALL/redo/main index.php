<?php
require_once('con1.php');

$customer_id = "";
$customer_name = "";
$gender = "";
$email = "";
$phone = "";
$error = "";

if(!empty($_POST)) {
	$customer_id = strtoupper(trim($_POST['id']));
	
	$customer_name = trim($_POST['customer_name']);
	
	if (isset($_POST['gender'])) {
		$gender = $_POST['gender'];
	}
	$email = $_POST['email'];
	
	$phone = $_POST['phone'];
	
	$error = array();
	
	if($customer_id ==null) {
		$error['customer_id'] = 'Please enter the Customer ID.';
	}
	
	if($customer_name ==null) {
		$error['customer_name'] = 'Please enter the Customer Name.';
	}
	if(!isset($_POST['gender'])) {
		$error['gender'] = 'Please enter the Gender.';
	}
	if($email == null){
		$error['email'] = 'Please enter the Email.';
	}
	if($phone == null) {
		$error['phone'] = 'Please enter the Phone.';
	}
	
	if (empty($error)) {
		$q = "INSERT INTO customer (customer_id,customer_name,gender,email,phone)
		VALUES('$customer_id','$customer_name','$gender','$email','$phone')";
		$r = mysqli_query($dbc, $q);
		
		if ($r) {
			echo "<p>The customer has been registered successful.</p>";
		} else {
			echo "<p>The customer cannot be registered succeddfully.</p>";
		}
		
		mySqli_close($dbc);
	} else {
		echo "<ul>";
		foreach ($error as $value) {
			echo "<li>$value</li>";
		}
		echo "</ul>";
	}
}
?>

<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
        <link href="package.css" rel="stylesheet" >
         <link href="body css.css" rel="stylesheet" >
         <link rel="stylesheet" href="headerfooter.css"/>
         <link rel="stylesheet" href="latest.css"/>
         <style>
          fieldset#custInfo
          {
          }
         </style>
         
    </head>
<body>
  <div class="right">
    <?php    
      include('header.php');
    ?>
  </div>
  <div class = "left">
    <div class="reservation">
         <form action="main index.php" method="post" > 
        <a href="listcustomer.php">list customer</a> 
            
        <div class="a">
      <h1>Basketball Court Reservation </h1>
        </div>
        <img class="basketball-court" src="basketball-court.jpg" alt=""/>
      
    <fieldset id="custInfo">
      <legend>Customer Information</legend>
	  
	  <br>
            <div class="elem-group">
                <td>CustomerID</td>
             <td> <input name="id" type="text"
			 value="<?php echo $customer_id; ?>" maxlength="20" /></td>
                </div>
		</br>
      
      <br>
            <div class="elem-group">
                <td>CustomerName</td>
             <td> <input name="customer_name" type="text"
			 value="<?php echo $customer_name; ?>" maxlength="20" /></td>
                </div>
		</br>
			
			<td>Gender:</td>
				<td>
				Female<input type="radio" name="gender" value="Female"
				<?php if ($gender == 'F') echo "checked='checked'"; ?> />
				Male<input type="radio" name="gender" value="Male"
				<?php if ($gender == 'M') echo "checked='checked'"; ?> />
			</td>
    <div class="elem-group">
      <br><td> E-mail</td>
      <p><td><input name="email" type="text"
	  value="<?php echo $email; ?>" maxlength="20" /></td></p>
    </div></br>
    
	<div class="elem-group">
      <td> Phone</td>
      <p><td><input name="phone" type="text"
	  value="<?php echo $phone; ?>" maxlength="20" /></td></p>
    </div>
    <hr>
    </div>
    <div class="elem-group inlined">
      <label for="date"> Date</label>
      <input type="date" id="date">
    </div>
    <div class="elem-group">
      <label for="payment-selection">Select payment </label>
      <select id="payment-selection" name="payment_preference">
          <option value="">Choose a payment from the List</option>
          <option value="CIMB BANK">CIMB BANK</option>
          <option value="PUBLIC BANK">PUBLIC BANK</option>
          <option value="visa ">Visa </option>
          <option value="MAYBANK ">MAYBANK </option>
          <option value="RHB ">RHB </option>
          <option value="HONG LEONG">HONG LEONG </option>
          <option value="IPAY88 ">IPAY88 </option>
          <option value="PAYPAL ">PAYPAL </option>
      </select>
    </div>
    <hr>
    <div class="elem-group">
      <label for="message">Anything Else?</label>
      <p><textarea id="message" name="visitor_message" placeholder="Tell us anything else that might be important."></textarea></p>
    </div>
   
    <input type="submit" value="submit" name="submit">
	<input type="reset" value="reset">
	<hr> 
           <section class="payment">
            <div>
              <h4>Payment channels</h4>
              <a id="a" href=""><img id="f1" src="Payment Icon.png"></a>
            </div>
               </hr>
        </section>
 

  </form>
  </fieldset id="custInfo">
  </div class="reservation">
</div class= "left">
<div class="footer">
            <p>TARUMT Basketball Society</p>
        </div>
  </body>
    </html>
  
  
    

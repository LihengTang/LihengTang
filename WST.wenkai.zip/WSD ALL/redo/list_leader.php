<?php
		include('con.php');
		$sql = "SELECT staff_id, staff_name, gender, job_position FROM admin";
		$result = $condb->query($sql);

		
		?>
<html>
<head>
	<meta charset="UTF-8">
    <link rel="stylesheet" href="list_leader.css"/>
	        <link rel="stylesheet" href="headerfooter.css"/>
        <link rel="stylesheet" href="about_us.css"/>
        <link rel="stylesheet" href="latest.css"/>
        <link rel="stylesheet" href="content.css"/>
	<title>	Leader_inforamtion</title>
<?php
if (mysqli_num_rows($result) > 0) {
?>
</head>

<body>
<div class="right">
    <?php    
        include('header(admin).php');
    ?>
</div>
<div class="left">
<?php
if (!empty($_POST)){
			
			
			$q = "Delete FROM admin WHERE staff_id IN ('". implode("','", 	$staff_id) ."')";
			$r = mysqli_query($condb,$q);
			
			if ($r) {
					echo  "<p align='center'>The staff has been deleted successfully.</p>";
			}else{
					echo  "<p align='center'>The staff cannot be deleted successfully.</p>";
				}
			}	
?>

<br><br><br>
		
		</br></br>
		<table border="6">
		<h1> - </h1>
		<tr>
		<th>Edit Info</th>
		<th>Delete Staff</th>
		<th>Staff_ID</th>
	    <th>Staff_Name</th>
		<th>Gender</th>
		<th>Position</th>
		</tr>
	 <?php
		
		$q = "SELECT * FROM admin";
		$r = @mysqli_query($condb, $q);
		$num = mysqli_num_rows($r);
		
		if ($num > 0) {
			while ($row = mysqli_fetch_array($r)) {
				printf('
					<tr>
					
						<td><a href="edit_func.php?staff_id='.$row['staff_id'].'">Edit</a></td>
						<td><a href="delete_leader.php?staff_id='.$row['staff_id'].'">Delete</a></td>
						<td>'.$row['staff_id'].'</td>
						<td>'.$row['staff_name'].'</td>
						<td>'.$row['gender'].'</td>
						<td>'.$row['job_position'].'</td>
					
							
						
					</tr>
				');
			}
			
			mysqli_free_result($r);
			
			mysqli_close($condb);
		}
		?>
</table>

	<a href="insert_leader.php"><input type="submit" name="submit" value="Add Staff">
</a>
 <?php
}
else
{
    echo "No result found";
}
?>
	</div>
</div class="left">
        <div class="footer">
            <p>TARUMT Basketball Society</p>
        </div>
</body>
</html>
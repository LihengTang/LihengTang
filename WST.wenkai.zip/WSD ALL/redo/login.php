<?php
require_once('connect.php');

session_start();
$login_error = "";
if(isset($_POST['submit']))
{
    $userID = stripcslashes($_POST['userID']);  
    $password1 = stripcslashes($_POST['password']);  
    $role = stripcslashes($_POST['roles']);  
    $userID = mysqli_real_escape_string($connect, $userID);  
    $password1 = mysqli_real_escape_string($connect, $password1);  

    if($_POST['roles'] = "admin")
    {
        $select = "SELECT * FROM admin WHERE UserID = '$userID' AND UserPassword ='$password1' AND AccType = '$role'";
        $result = mysqli_query($connect,$select);
        $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
        $count = mysqli_num_rows($result); 
        if($count == 1)
        {
            header('location:home(admin).php');
        }
        else
        {
            $login_error = "Invalid UserID and Password.";
        }
    }
    if($_POST['roles'] = "client")
    {
        $select = "SELECT * FROM user WHERE UserID = '$userID' AND UserPassword ='$password1' AND AccType = '$role'";
        $result = mysqli_query($connect,$select);
        $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
        $count = mysqli_num_rows($result);
        if($count == 1)
        {
            header('location:home.php');
        }
        else
        {
            $login_error = "Invalid UserID and Password.";
        }
    }
    else
    {
        $login_error = "Invalid UserID and Password.";
    }

}
?>

<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="headerfooter.css"/>
    <link rel="stylesheet" href="login.css"/>
    <link rel="stylesheet" href="latest.css"/>
    <script>
  function preventBack(){window.history.forward();}
  setTimeout("preventBack()", 0);
  window.onunload=function(){null};
</script>
    <title>Login</title>
</head>
<body>
    <div class="whole">
    <br><br><br><br>
    <div class="left">
        <fieldset>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <h2>USER LOGIN</h2>
                <div>
                    <select name="roles">
                        <option value="admin">Admin</option>
                        <option value="client">Client</option>
                    </select>
                </div>
                <div>
                    <img id="name1" src="user.png" alt="name">
                    <input id="username" class="username" type="text" name="userID" placeholder="Enter your userID">
                </div>
                <br>  
                <div>
                    <img id="password1" src="password.png" alt="password">
                    <input id="password" class="password" type="password" name="password" placeholder="Enter your password">
                </div>
                <p id="error" class="error">
                    <?php 
                        echo $login_error; 
                    ?>
                </p>  
                <nav class="buttons">
                    <button id="submit" name="submit" type="submit">Login</button>
                    <button id="cancel" name="cancel" type="reset" >Reset</button>
                    <button id="cancel" name="cancel" onclick="history.back()">Cancel</button>
                </nav>
                <br>
                <p class="new">Didn't Have Account?
                    <a href="signup.php">Sign Up</a>
                </p>
                
            </form> 
        </fieldset>
    </div>
    <div class="footer">
        <p>TARUMT Basketball Society</p>
    </div>
</body>
</html>
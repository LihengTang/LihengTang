<?php
require_once('connect.php');

$student_id = "";
$student_name = "";
$email = "";
$phone = "";
$gender = "";
$error = "";

if(!empty($_POST))
{
	$student_id = strtoupper(trim($_POST['studentid']));
	$student_name = trim($_POST['student_name']);
	if(isset($_POST['gender']))
	{
		$gender = $_POST['gender'];
	}
	$error = array();
	if($student_id == null)
	{
		$error['studentid'] = "Please Enter Student ID.";
	}
	if($student_name == null)
	{
		$error['student_name'] = "Please Enter Student Name.";
	}
	if($gender == null)
	{
		$error['gender'] = "Please Enter Gender.";
	}

	if(empty($error))
	{
        $q = "INSERT INTO user (UserID, Username, Gender, PhoneNumber, Email) VALUES('$student_id','$student_name','$gender','$phone','$email')";
        $r = mysqli_query($connect,$q);
        if($r)
        {
            echo"<p>Student Has Been Registered Successfully.</p>";
        }
        else
        {
            echo"<p>An Error has occured. Student Hasn't Been Registered Successfully.</p>";
        }
        mysqli_close($connect);
	}
	else
	{
		echo"<ul>";
		foreach($error as $value)
		{
			echo"<li>$value</li>";
		}
		echo"</ul>";
	}
	
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="headerfooter.css"/>
        <link rel="stylesheet" href="latest.css"/>
        <title>User Info</title>
        <style>
            table,th,td{

                border:1px solid black;
            }
        </style>
    </head>
    <body>
        <div class="whole">
            <?php    
                include('header(admin).php');
            ?>
            <div class="left">
            <div class ="event">
            </br> 
            [<a href="userinfo.php">Back</a>]
            <h1>Insert New User</h1>
        <fieldset>
                <form action="" method="post">
                    <div class="z">
                        <label>User ID: </label>
                        <td colspan="2"><input type="text" id="student_id" name="studentid"  value="<?php echo $student_id;?>" maxlength="10"></td>
                    </div>
                    </br>
                    <div class="z">
                        <label>User Name: </label>
                        <td colspan="2"><input type="text" id="student_name" name="student_name" value="<?php echo $student_name;?>"></td>
                    </div> 
                    </br>
                    <div class="z">
                        <label>Email Address: </label>
                        <td colspan="2"><input type="text" id="student_name" name="email" value="<?php echo $email;?>"></td>
                    </div> 
                    </br>
                    <div class="z">
                        <label>Phone Number: </label>
                        <td colspan="2"><input type="text" id="student_name" name="phone" value="<?php echo $phone;?>"></td>
                    </div> 
                    </br>
                    <div class="z">
                        <label>Gender: </label>
                        <td colspan="2"><input type="text" id="student_name" name="gender" value="<?php echo $gender;?>"></td>
                    </div> 
                    </br>
                    <button type="submit"name="submit">Submit</button>
                    <button type="button"onclick="location='userinfo.php'">Cancel</button>
                </form>
        </fieldset>
                </div>
            </div>
        </div>
        </div>
        <div class="footer">
            <p>TARUMT Basketball Society</p>
        </div>
    </body>
</html>
<html>
	<head>
		<link rel="stylesheet" href="headerfooter.css"/>
        <link rel="stylesheet" href="about_us.css"/>
        <link rel="stylesheet" href="latest.css"/>
		<title>Edit Events</title>
	</head>
<body>
<div class="right"></div>
    <?php    
        include('header(admin).php');
    ?>
</div>
<?php require_once('connect.php');?>
<?php

if(isset($_POST['submit'])){
$title= $_POST['title'];
$des= $_POST['des'];
if(isset($_POST['delete'])){
$delete =  $_POST['delete'];
}}
$user ='99';
if(isset($_FILES['img'])){
$image= $_FILES['img'];
$imgname= $_FILES['img']['name'];
$imgerror= $_FILES['img']['error'];
$imgsize= $_FILES['img']['size'];
$imgfile = 'htdocs'.$imgname;
$imgtemp = $_FILES['img']['tmp_name'];
$imgtype = $_FILES['img']['type'];
}

$error = detectInputError();


function detectInputError(){

global $title, $des, $imgerror, $imgsize, $imgtype;
$error = array();



if(isset($_POST['submit'])){
if($title ==NULL){$error['title'] =' Key in the title ';}
if($des == NULL){$error['des'] ='Key in the describe ';}

}
if(isset($_FILES['img'])){
if($imgsize >1250000000000000	){$error['img'] = 'File too large';}
if($imgtype!=NULL){if($imgtype != 'image/png'&& $imgtype !='image/jpeg'&&$imgtype !='image/jpg'){$error['imgtyp'] = 'Not an image';}}
}

return $error;
}

if(isset($_POST['submit'])){
if(!isset($_POST['delete'])){
if($error !=null){echo"<h1>OPSS... There are some Error</h1>";
   echo"<ul>";
   foreach($error as $value){
   printf("<li>$value</li>");}
   echo"</ul>";}
else{
 
move_uploaded_file($imgtemp,$imgfile);

$q ="UPDATE `event` SET `title`='".$title."',`describe`='".$des."',`image`='htdocs".$imgname."' WHERE `user`='".$user."'";
$r = @mysqli_query($connect, $q); }   
}else{
	$code = "DELETE FROM `event` WHERE `user`='".$user."'";
	$r = @mysqli_query($connect, $code);
	echo" The event has been delete";
}



mysqli_close($connect);}
?>
<style>
form{
width:100mm;	
margin:auto;
background-color:white;
border:outset 5px rgb(77, 77, 255);
margin-top:18px;
}
textarea{resize:none;}
h1{
text-align:center;
font-size:5em;
font-family:sans-serif;
border:double 10px rgb(77, 77, 255);
width:130mm;
margin:auto;
background-color:white;

}
html{
	background-color:rgb(0, 45, 179);
}
body{
	background-color:rgb(153, 179, 255);
	width:330mm;
	margin:auto;
	border:groove 10px rgb(0, 45, 179);
}
p{
	background-color:rgb(0, 45, 179);
	color:white;
	width:365px;
	margin-left:-10px;
}
</style>
<br>
<div class="left">
<br>
<h1>Edit Event</h1><br>
<form action="editevent.php" method="post" enctype="multipart/form-data">
<fieldset><br>
Title: <input name="title" type="text" value="<?php if(isset($_POST['submit'])) echo $title;?>" ><br><br>
Description: <textarea name="des" rows="5" cols="40" value="<?php echo $des;?> "></textarea><br><br>
Image: <input name="img" type="file" value="<?php echo $imagename;?> "><br><br>
<button type="submit" name="submit">submit</button>
<button type="reset">reset</button>
<p>If you really want to delete the event, please tick the checkbox and press the submit button<input type="checkbox" name="delete" value="delete"> </p>
</fieldset>
</form>
</div class="left">
<div class="footer">
    <p>TARUMT Basketball Society</p>
</div>
</body>
</html>

<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="information.css"/>
        <form method="post" action="register form.php">
        <title>Announcement</title>

    </head>
    <fieldset id="def">
    <body>
         <img class="p1jpg" src="p1.jpg" alt="">
     <div class="a">
         
        <h1>TARUMT BASKETBALL SOCIETY</h1>
     </div>
         
            <h2>Welcome Our New Coach !!!</h2> 
            <div class="b">
                 
            <h3>- We are pleased to announce that Malaysian Development
                Basketball League MVP Qiu Jiahao will serve as our TARUMT basketball coach.</h3>
           
            <h3>- Jiahao won the national championship in the Malaysian Development 
                Basketball League last season, and recently represented Malaysia in the 
                FIBA 3X3 Asia Cup, and brought a wealth of game experience to the club.</h3>
            
            <h3>- He is very qualified to serve as tarumt's basketball academy coach.</h3>
        
        </div><br>
        <div id="mvp">
            <img src="mvp.jpg" width="350px" height="250px" alt="">
        </div>
         
         <hr>
         <div class="c">
             <h3>BASKETBALL TEAM ELITE RECRUITMENT</h3>
             <br> <h3>- We want you for our University basketball team! The recruitment is open to all TAR UMT Perak Branch!</h3>
             <br> <h3>- No matter Male or Female,only if Tarumt Perak Branch students who are interested  can participate.</h3>
         </div>
         <div id="p2">
             <img src="p2.jpg" width="350px" height="250" alt="">
         </div>
         <hr>
    </body>
    </fieldset>
</html>

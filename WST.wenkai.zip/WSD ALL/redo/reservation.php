<html>
    <head>
        <meta charset="UTF-8"/>
        <link rel="stylesheet" href="headerfooter.css"/>
        <link rel="stylesheet" href="reservation.css"/>
        <title>Home Page</title>
        <style>

        </style>
    </head>

    <body>
        <div class="right">
            <?php    
                include('header.php');
            ?>
        </div>
        <div class="left">
            <div class="reservation">
                <form method="post" action="check information result.php"> 
                    <div class="a">
                        <h1>Basketball Court Reservation </h1>
                    </div>
                    <img class="basketball-court" src="basketball-court.jpg" alt=""/>
                    <fieldset id="custInfo">
                        <legend>Customer Information</legend>
                        <br>
                        <div class="elem-group">
                            <label for="name">Your Name</label>
                            <td colspan="2"><input type="text" name="name" value="User1"></td>
                        </div>
                        </br>
                        <td>Gender:</td>
                        <td>
                            <input type="radio" name="gender" value="M" checked/>
                            Male
                            <input type="radio" name="gender" value="F"/>
                            Female
                        </td>
                        <div class="elem-group">
                            <br>
                        <label for="email">Your E-mail</label>
                        <p>
                            <td colspan="2"><input type="text" name="email" value="user1@gmail.com"></td>
                        </p>
                        </div>
                        </br>
                        <div class="elem-group">
                            <label for="phone">Your Phone</label>
                            <p>
                                <td colspan="2"><input type="text" name="phone" value="011-11834349"></td>
                            </p>
                        </div>
                        </br>
                        <div class="elem-group">
                            <label for="place-selection">Select place Preference</label>
                            <td colspan="2"><small>(choose a place from a list)</small></td>
                            <?php 
                                $place=array(   
                                "Kp"=>'Kampar',
                                "Ip"=>'Ipoh',
                                "Tn"=>'Tronoh',
                                "TT"=>'Tanjong Tualang',
                                "PP"=>'Pulau Pinang');
                                foreach($place as $key => $value){
                                    echo"<tr>
                                        <td> </td>
                                        <td colspan='2'><input type='checkbox' name='place[]' value='$key'>$value</td>
                                    </tr>";}
                            ?>
                        </div>
                        <div class="elem-group inlined">
                            <label for="date"> Date</label>
                            <input type="date" id="date">
                        </div>
                        <div class="elem-group">
                            <label for="payment-selection">Select payment </label>
                                <select id="payment-selection" name="payment_preference">
                                <option value="">Choose a payment from the List</option>
                                <option value="CIMB BANK">CIMB BANK</option>
                                <option value="PUBLIC BANK">PUBLIC BANK</option>
                                <option value="visa ">Visa </option>
                                <option value="MAYBANK ">MAYBANK </option>
                                <option value="RHB ">RHB </option>
                                <option value="HONG LEONG">HONG LEONG </option>
                                <option value="IPAY88 ">IPAY88 </option>
                                <option value="PAYPAL ">PAYPAL </option>
                            </select>
                        </div>
                        <br>
                        <div class="elem-group">
                            <label for="message">Anything Else?</label>
                            <p><textarea id="message" name="visitor_message" placeholder="Tell us anything else that might be important."></textarea></p>
                        </div>
                        <input type="submit" value="submit" name="submit">&nbsp;<input type="reset" value="reset">
                        </br>
                        <section class="payment">
                            <div>
                                <h4>Payment channels</h4>
                                <a id="a" href=""><img id="f1" src="Payment Icon.png"></a>
                            </div>
                            </br>
                        </section>
                    </fielset>
                </form>
            </div>
        </div>
        <div class="footer">
            <p>TARUMT Basketball Society</p>
        </div>
    </body>
</html>
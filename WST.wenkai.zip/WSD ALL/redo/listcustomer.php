<?php
require_once('con1.php');
require_once('data1.php');

?>
<html>
<head>
    
<title>Student Information</title>
<meta charset='UTF-8'>
<link rel="stylesheet" href="listcustomer.css"/>
<link rel="stylesheet" href="headerfooter.css"/>
<link rel="stylesheet" href="latest.css"/>
</head>
<body>
<div class="right">
    <?php    
      include('header.php');
    ?>
  </div>
<div class="left">
<form action="listcustomer.php" method="post">
<p>
[<a href="main index.php">Main Index</a>][<a href="listcustomer.php">List Customer</a>]
</p>
<h1>List Customer</h1>
<?php  
    if(!empty($_POST)) {
		$customer_id = $_POST['checked'];
		
		$q="DELETE FROM customer WHERE customer_id IN ('". implode("','",$customer_id) ."')";
		$r= mysqli_query($dbc, $q);
		
		if($r) {
			echo "<p>The customer has been deleted successfully.</p>";
		} else {
			echo "<p>The customer cannot be deleted successfully.</p>";
        }
	}
?>
<table border="1" cellpadding="6" cellspacing="0">
	<tr>
	   
		<th>Customer ID</th>
		<th>Customer Name</th>
		<th>Gender</th>
		<th>E-mail</th>
		<th>Phone</th>
		<th>Action</th>
	</tr>
    <?php  
    
	$q = "SELECT * FROM customer";
	$r = mysqli_query($dbc,$q);
	$num = mysqli_num_rows($r);
	if($num>0){
		while($row= mysqli_fetch_array($r)){
			printf('
				<tr>
				    
					<td>'.$row['customer_id'].'</td>
					<td>'.$row['customer_name'].'</td>
					<td>'.$row['gender'].'</td>
					<td>'.$row['email'].'</td>
					<td>'.$row['phone'].'</td>
					<td align="center">
					    <a href="edit-customer.php?id='.$row['customer_id'].'">Edit</a>
						<a href="delete-customer.php?id='.$row['customer_id'].'">Delete</a>
					</td>
				</tr>
			');
		}
	}
	printf('
			<tr>
				<td colspan="6">'.$num.' record(s) returned. </td>
			</tr>
		');

			
	mysqli_free_result($r);
	
	mysqli_close($dbc);
?>
</table>
<br/>
<br>

</br>
</form>
<input type="submit" name="delete" value="Delete" 
onclick="return confirm('Are you sure to delete all the checked records?')"/>
</div class="left">
<div class="footer">
            <p>TARUMT Basketball Society</p>
        </div>
</body>
</html>
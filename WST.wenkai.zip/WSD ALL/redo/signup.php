<?php
require_once('connect.php');

$UserID = "";
$UserName = "";
$email = "";
$pass = "";
$cpass = "";
$error = "";

if(!empty($_POST))
{
	$UserID = strtoupper(trim($_POST['userID']));
	$UserName = trim($_POST['username']);
    $email = trim($_POST['email']);
    $pass = trim($_POST['password1']);
    $cpass = trim($_POST['password2']);

	$error = array();
	if($UserID == null)
	{
		$error['UserID'] = "Please Enter Student ID.";
	}
	if($UserName == null)
	{
		$error['username'] = "Please Enter Student Name.";
	}
    if($email == null)
	{
		$error['email'] = "Please Enter Email Address.";
	}
    if($pass == NULL)
    {
        $error['password1'] = "Please Enter Password.";
    }
    if($pass != $cpass)
    {
        $error['password2'] = "Password Not Match.";
    }

	if(empty($error))
	{
        $q = "INSERT INTO user (UserID, UserName, Email,UserPassword) VALUES('$UserID','$UserName','$email','$pass')";
        $r = mysqli_query($connect,$q);
        if($r)
        {
            echo"<p>User Has Been Sign Up Successfully.</p>";
        }
        else
        {
            echo"<p>An Error has occured. User Hasn't Been Sign Up Successfully.</p>";
        }
        mysqli_close($connect);
	}
	else
	{
		echo"<ul>";
		foreach($error as $value)
		{
			echo"<li>$value</li>";
		}
		echo"</ul>";
	}
	
}
?>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="headerfooter.css"/>
    <link rel="stylesheet" href="signup.css"/>
    <link rel="stylesheet" href="latest.css"/>
    <form method="post" action="signup.php">
    <title>Sign Up</title>
</head>
<body>
    <div class="whole">
    <br><br><br><h1>SIGN UP FORM</h1><br>
        <div class="left">
            <fieldset>
                <h2>SIGN UP</h2>
                <h4>** required<h4>
                <form action="" method="post">
                    <div class="z">
                        <label for="email">StudentID: **</label>
                        <td colspan="2"><input type="text" id="student" name="userID" placeholder="2*A**0***9"></td>
                    </div>
                    </br>
                    <div class="z">
                        <label for="name">User Name: **</label>
                        <td colspan="2"><input type="text" id="name" name="username" placeholder="J*** D**"></td>
                    </div> 
                    </br>
                    <div class="phnone">
                        <label for="phone">Email Address: **</label>
                        <td colspan="2"><input type="text" id="phone" name="email" placeholder="***@gmail.com"></td>
                    </div>
                    </br>
                    <div class="z">
                        <label for="userID">Password: **</label>
                        <td colspan="2"><input type="text" id="UserID" name="password1" placeholder="Enter Your Password"></td>
                    </div>
                    <div class="z">
                        <br>
                        <label for="userID">Re-enter Password: **</label>
                        <td colspan="2"><input type="text" id="UserID" name="password2" placeholder="Confirm Your Password"></td>
                    </div>
                    </br>
                    <button type="submit"name="submit">Submit</button>
                    <button type="reset">Reset</button>
                    <button onclick="history.back()">Cancel</button>
                    <p class="new">Already Have An Account?
                    <a href="login.php">Login</a>
                </p>
                </form>
            </fieldset>
        </div>
        <div class="footer">
            <p>TARUMT Basketball Society</p>
        </div>
</body>
</html>
<nav class="right">
    <div class ="button">
        <div class="upper">
            <div>
                <a class="right"href="home.php">
                    <img id="logo"src="logo.png" alt="Basketball Society">
                </a>
            </div>
        </div>
        <div class="lower">
            <div class ="rightmiddle">
                <ul class="lower">
                    <li class="right">
                        <div class="rightinner">
                            <a class="right"href="home.php">HOME</a>
                        </div>
                    </li>
                    <br>
                    <li class="right">
                        <div class="rightinner">
                            <a class="right"href="myaccount.php">MY ACCOUNT</a>
                        </div>
                    </li>
                    </br>
                    <li class="right">
                        <div class="rightinner">
                            <a class="right"href="main index.php">RESERVATION</a>
                        </div> 
                    </li>
                    <br>                             
                    <li class="right">    
                        <div class="rightinner">
                            <a class="right"href="event.php">EVENTS</a>
                        </div> 
                    </li>
                    <br>
                    <li class="right">
                        <div class="rightinner">
                            <a class="right"href="announcement.php">ANNOUNCEMENTS & UPDATES</a>
                        </div>
                    </li>
                    <br>
                    <li class="right">
                        <div class="rightinner">
                            <a class="right"href="logout.php">LOG OUT</a>
                        </div>
                    </li>
                    <br>
            </div>
            <div class="social">
                <ul>
                    <li class="right">
                        <a class="right"href="https://www.facebook.com/"target="_blank">
                            <img id="social1"src="facebook.png"alt="Facebook">
                        </a>
                        <a class="right"href="https://www.instagram.com/"target="_blank">
                            <img id="social1"src="instagram.png"alt="Instagram">
                        <a class="right"href="https://www.youtube.com/"target="_blank">
                            <img id="social2"src="youtube.png"alt="Youtube">
                        </a>
                    </li class="right">
                    <li class="right">
                        CONTACT US: <a class="right"href="">012-345678</a>
                    </li class="right">
                </ul> 
            </div>
        </div>
    </div>
</nav>

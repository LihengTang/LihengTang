<?php
session_start();
require_once('connect.php');
$userID = "ADMIN001";
?>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="headerfooter.css"/>
        <link rel="stylesheet" href="about_us.css"/>
        <link rel="stylesheet" href="latest.css"/>

        <title>My Account</title>
        <style>
            table{
                margin-right: auto;
                width:80%;
            }
            th,td
            {
                padding:5px;

            }
        </style>
    </head>
    <body>
        <div class="right"></div>
            <?php    
                include('header(admin).php');
            ?>
        </div>
        <?php
        $q = "SELECT * FROM `admin` WHERE UserID ='$userID'";
        $r = mysqli_query($connect,$q);
        $num = mysqli_num_rows($r);
        if ($num > 0)
        {
            $row = mysqli_fetch_array($r);
        }
        ?>
        <div class="left">
        <div class="aboutus">
                <h1>My Account</h1>
                    <div>
                        <table>
                            <tr>
                                <td><img src="p5.jpg" width="200px" height="250px" alt=""/></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>User ID</td>
                                <td>:</td>
                                <td><?php echo $row['UserID']; ?></td>
                                <td><?php printf('[<a href="editadmin.php?id='.$row['UserID'].'">Edit</a>]');?></td>
                            </tr>
                            <tr>
                                <td>UserName</td>
                                <td>:</td>
                                <td><?php echo $row['Username']; ?></td>
                                
                            </tr>
                            <tr>
                                <td>Email Address</td>
                                <td>:</td>
                                <td><?php echo $row['Email']; ?></td>
                            </tr>
                            <tr>
                                <td>Gender</td>
                                <td>:</td>
                                <td><?php echo $row['Gender']; ?></td>
                            </tr>
                            <tr>
                                <td>Phone Number</td>
                                <td>:</td>
                                <td>+60
                                    <?php echo
                                        $row['PhoneNumber'];        
                                        mysqli_free_result($r);
                                        mysqli_close($connect);
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><a href="editpassword.php">[Edit Password]</a></td>
                            </tr>
                        </table>
		            </div>
                </br>
                </br>
        </div>
        </div>

        <div class="footer">
            <p>TARUMT Basketball Society</p>
        </div>
    </body>
</html>
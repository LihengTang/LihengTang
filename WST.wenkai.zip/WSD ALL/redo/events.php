<html>
<?php require_once('connect.php'); ?>

<head>
  <link rel="stylesheet" href="headerfooter.css"/>
  <link rel="stylesheet" href="latest.css"/>
  <link rel="stylesheet" href="content.css"/>
  <title>Events</title>
<style>
.y{
  -moz-hyphens:auto;
-ms-hyphens:auto;
-webkit-hyphens:auto;
hyphens:auto;
word-wrap:break-word;
   text-align:left;
   margin-left:-188mm;
   border:dashed 10px;
   width:180mm;
   height:30em;
   margin-bottom:-20px;
 background-color:#FFD2C7;
}

.n{
  -moz-hyphens:auto;
-ms-hyphens:auto;
-webkit-hyphens:auto;
hyphens:auto;
word-wrap:break-word;
  text-align:left;
  border:dashed 10px;
  width:310mm;
  height:30em;
  margin-bottom:-20px;
  background-color:#FFD2C7;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: rgba(0,0,0,0.7);
  overflow-x: hidden;
  padding-top: 60px;
  text-align:center;
}
.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: white;
  display: block;
}
.sidenav a:hover{
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}
</style>
</head>

<body>
          <div class="right">
            <?php    
                include('header(admin).php');
            ?>
        </div>
<div class="left">
  <table>
    [<a href="addevents.php">Insert New Event</a>]
    <tr>
      <th>Title</th>
      <th>More Information</th>
      <th>Edit</th>
    </tr>
    <?php
$user = '99';
$q = "SELECT * FROM event";
$r = @mysqli_query($connect,$q);
$show = @mysqli_num_rows($r);

while($row  = mysqli_fetch_array($r))
{	
	printf('<tr>
            <td>'.$row['Title'].'</td> 
            <td>
              <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;Press Here</span>
              <div id="mySidenav" class="sidenav">
                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                <div class="event">
                  <table>
                    <tr>
                      <td>
                        <img src="'.$row['image'].'.jpg"width="550px" height="450px">
                      </td>
                      <td>
                        <div class="d">'.$row['EventDescription'].'</div>
                      </td>
                    </tr>
                  </table>
                </div>
              </div>
            </td>  
            <td>[<a href="editevent.php">Edit</a>]</td>
          </tr>');
}
?>
</table>
<input type="submit" name="delete" value="Delete" 
onclick="return confirm('Are you sure to delete all the checked records?')"/>
</div class="left">
<div class="footer">
  <p>TARUMT Basketball Society</p>
</div>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "100%";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
</body>

</html>
<?php
require_once('con1.php');
require_once('data1.php');

$customer_id = $_REQUEST['id'];
$customer_name = "";
$gender = "";
$email = "";
$phone = "";
$message = "";

if(!empty($_POST)) {
	$customer_id = strtoupper(trim($_POST['id']));
	
	$q = "DELETE FROM customer WHERE customer_id = '$customer_id'";
	$r = mysqli_query($dbc, $q);
		
	if ($r) {
		echo "The customer has been deleted successfully.";
	} else {
		echo "The customer cannot be deleted successfully.";
	}
	
	$customer_id = "";
	$customer_name = "";
	$gender = "";
	$email = "";
	$phone = "";
}else{
	$q = "SELECT * FROM customer WHERE customer_id = '$customer_id'";
	$r = mysqli_query($dbc, $q);

	if (mysqli_num_rows($r) == 1) {
		$row = mysqli_fetch_array($r);
		$customer_id = $row['customer_id'];
		$customer_name = $row['customer_name'];
		$gender = $row['gender'];
		$email = $row['email'];
		$phone = $row['phone'];
	}
	mysqli_free_result($r);
}

mysqli_close($dbc);
?>

<!DOCTYPE html>
<html>
<head>
<style>
table td {
	width: 50%;
}
</style>
<title>Delete Customer</title>
	<meta charset="UTF-8">
    <link rel="stylesheet" href="delete-customer.css"/>
</head>
<body>

<h1>Delete Customer</h1>
<?php
if($message){
	echo "<p>".$message."</p>";
}
if (empty($_POST))
?>
<p>Are you sure you want to delete the following customer?</p>
<form action="delete-customer.php" method="post">
<input type="submit" name="delete" value="Yes"/>
	<a href="listcustomer.php">
		<input type="button" name="cancel" value="No">
	</a>


	<table border="1" cellpadding="5" cellspacing="0">
	    <tr>
			<th>Customer ID:</th>
			<td><?php echo $customer_id; ?>
			<input type="hidden" name="id" value="<?php echo $customer_id; ?>" maxlength="20" />
			</td>
		</tr>
		<tr>
			<th>Customer Name:</th>
			<td><?php echo $customer_name; ?>
			<input type="hidden" name="customer_name" value="<?php echo $customer_name; ?>" maxlength="20" />
			</td>
		</tr>
		<tr>
			<th>Gender:</th>
			<td><?php if ($gender) echo $gender; ?></td>
		</tr>
		<tr>
			<th>email:</th>
			<td><?php if ($email) echo $email; ?></td>
		</tr>
		<tr>
			<th>phone:</th>
			<td><?php if ($phone) echo $phone; ?></td>
		</tr>
	</table>
	
</form>
</body>
</html>
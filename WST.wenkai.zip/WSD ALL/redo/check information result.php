 <form method="post" action="main2 check.php"> 
<?php
       function detectInputError(){
	
	global $name,$gender,$email,$phone,$place;
	
	$error=array();
        
         if($name==null){
		$error['name']='Please enter your name.';
	}
	else if(!preg_match('/^[A-Za-z@,\'\ \.\-\/]+$/', $name)){
		$error['name']="There are invalid characters in your name.";
	}
	else if(strlen($name) > 30){
		$error['name']="Name must be less than 30 characters.";
        }
	if($gender==null){
		$error['gender']='Please select your gender.';
        }
	else if(!preg_match('/^[MF]$/', $gender)){
		$error['gender']="Gender can only be either M or F.";
        }
        
	if($email==null){
		$error['email']='Please enter your email.';
        }
	else if(!preg_match('/^[A-Za-z@,\'\ \.\-\/]+$/', $email)){
		$error['email']='There are invalid characters in your email';
        }
        else if(strlen($email) > 30){
		$error['email']="Email must be less than 30 characters.";
        }
	if($phone==null){
		$error['phone']='Please enter your phone number.';
	}
	else if(!preg_match("/^[0][1]\d{1}\-\d*$/",$phone)){
		$error['phone']="Please enter numeric value that start with 01 and dash "; 
	}
	else if(strlen($phone)!=11 && strlen($phone)!=12){
		$error['phone']="Please enter 10 or 11 digit only"; 
	}
        
        if($place==null){
		$error['place']='Please select place you want to choose.';
	}
	else if (count($place)>3){
		$error['place']='You cannot select more than 1 place.';
	}
        
	
	if($gender !=null && $place !=null){
		if($gender =='M' && in_array('TT',$place)){
			$error['gender']='Sorry,males cannot select Tanjong Tualang ';
                }
		else if ($gender =='F' && in_array('PP',$place)){
			$error['gender']='Sorry,females cannot select Pulau Pinang';
                }
	}
	
	return $error;
}
function getname(){
    return array('JS'=>'Jane Smith',
                    'jl'=>'john lee',
                    );
}

function getplace(){
    return array('Kp'=>'Kampar',
                    'Ip'=>'Ipoh',
                    'Tn'=>'Tronoh',
                    'TT'=>'Tanjong Tualang',
                    'PP'=>'Pulau Pinang');
}
function getpayment(){
	return array('CB'=>'CIMB BANK',
		            'PB'=>'PUBLIC BANK',
                            'MB'=>'MAYBANK',
                            'RHB'=>'RHB',
                            'HL'=>'HONG LEONG',
                            'IP'=>'IPAY88',
                            'PP'=>'PAYPAL',
                             );
        
}
?>
<html>
<head>
<style>
.error{
	color:red;
}
</style>
</head>

<body>
<?php

if(isset($_POST['submit'])){
    
       if(isset($_POST['name'])){
		$name=trim($_POST['name']);
	}
        
	
	if(isset($_POST['gender'])){
		$gender=$_POST['gender'];
	}
	
	if(isset($_POST['email'])){
		$email=$_POST['email'];
	}
	
	if(isset($_POST['phone'])){
		$phone=trim($_POST['phone']);
	}
        
        if(isset($_POST['place'])){
		$place=$_POST['place'];
	}
        
	
	$error=detectInputError();
	if(empty($error)){
		$allplace =getplace();
		echo "<h1>Thanks for Reservation</h1>";
		if($gender='M')
			echo "<h3>Mr. $name</h3>";
		else
			echo "<h3>Ms. $name</h3>";
			  
		echo "<p>You have select the following place: </p>";	  
		echo"<ul>";
			 foreach ($place as $value){
				echo "<li>$allplace[$value] ($value)</li>";
			}
		echo"</ul>";
		
	}
	else{
		printf('
		<h1>OOPS... There are input errors</h1>
		<ul><li class="error">%s</li></ul>
		<p><a href="javascript:history.back()">Back</a></p>
		',implode('</li><li class="error">',$error));
	}
}

     
    ?>
    <button onclick="window.location.href='main2 check.php'">Check</button>
  </body>
    
  
  
    
<form method="post" action="main3 index2.php"> 
<?php
       function detectInputError(){
	
	global $name,$name;
	
	$error=array();
        
         if($name==null){
		$error['name']='Please enter your name.';
	}
	else if(!preg_match('/^[A-Za-z@,\'\ \.\-\/]+$/', $name)){
		$error['name']="There are invalid characters in your name.";
	}
	else if(strlen($name) > 30){
		$error['name']="Name must be less than 30 characters.";
        }
        
         if($name==null){
		$error['name']='Please enter your name.';
	}
	else if(!preg_match('/^[A-Za-z@,\'\ \.\-\/]+$/', $name)){
		$error['name']="There are invalid characters in your name.";
	}
	else if(strlen($name) > 30){
		$error['name']="Name must be less than 30 characters.";
        }
        return $error;
       }
       ?>
        <html>
<head>
<style>
.error{
	color:red;
}
</style>
</head>

<body>
<?php

if(isset($_POST['submit'])){
	
	if(isset($_POST['name'])){
		$name=trim($_POST['name']);
	}
        if(isset($_POST['name'])){
		$name=trim($_POST['name']);
	}
        
        $error=detectInputError();
	if(empty($error)){
		echo "<h1>Thanks for Check !</h1>";
		if($gender='M')
			echo "<h3>Mr. $name</h3>";
		else
			echo "<h3>Ms. $name</h3>";
	}
	else{
		printf('
		<h1>OOPS... There are input errors</h1>
		<ul><li class="error">%s</li></ul>
		<p><a href="javascript:history.back()">Back</a></p>
		',implode('</li><li class="error">',$error));
	}
}
        ?>
    <button onclick="window.location.href='main3 index2.php'">Enter</button>
</body>

<?php
function getGenders(){
    return array(
	    'F' => 'Female',
		'M' => 'Male',
	);
}

	



$GENDERS = getGenders();

?>

<?php
session_start(); // start the session
setcookie(session_name(), '', 100);
session_unset(); // unset all session variables
session_destroy(); // destroy the session
// redirect the user to the login page
header("Location: login.php");
exit;
?>

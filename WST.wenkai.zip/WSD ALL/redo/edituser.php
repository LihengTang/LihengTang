<?php
require_once('connect.php');

$student_id = $_REQUEST['id'];
$student_name = "";
$gender = "";
$email = "";
$phonenumber = "";
$error = "";

if(!empty($_POST))
{
	$student_id = strtoupper(trim($_POST['id']));
	$student_name = trim($_POST['student_name']);
	if(isset($_POST['gender']))
	{
		$gender = $_POST['gender'];
	}
	$error = array();
    if($student_id == null)
	{
		$error['studentid'] = "Please Enter UserID.";
	}
	if($student_name == null)
	{
		$error['student_name'] = "Please Enter UserName.";
	}
	if($gender == null)
	{
		$error['gender'] = "Please Enter Gender.";
	}
	if(empty($error))
	{
        $q = "UPDATE user SET UserName = '$student_name',Email = '$email', Gender = '$gender', PhoneNumber= '$phonenumber' WHERE UserID ='$student_id'";
        $r = mysqli_query($connect,$q);
        if($r)
        {
            echo"<p>User's Details Has Been Updated Successfully.</p>";
        }
        else
        {
            echo"<p>An Error has occured. User's Details Cannot Be Update Successfully.</p>";
        }
        
	}
	else
	{
		echo"<ul>";
		foreach($error as $value)
		{
			echo"<li>$value</li>";
		}
		echo"</ul>";
	}
	
}
$q = "SELECT * FROM `user` WHERE UserID = '$student_id'";
$r = mysqli_query($connect,$q);
if(mysqli_num_rows($r) == 1)
{   
    $row = mysqli_fetch_array($r);
    $student_id = $row['UserID'];
    $student_name = $row['Username'];
    $email = $row['Email'];
    $gender = $row['Gender'];
    $phonenumber = $row['PhoneNumber'];
}

mysqli_free_result($r);
mysqli_close($connect);
?>
<html>
    <head>
    <link rel="stylesheet" href="headerfooter.css"/>
    <link rel="stylesheet" href="latest.css"/>
    <title>Edit User Info</title>
    </head>
    <body>
    <?php    
        include('header(admin).php');
    ?>
    <div class="left">
        <div class ="event">
        <h1>Edit User</h1>
        <fieldset>
                <form action="edituser.php" method="post">
                    <div class="z">
                        <label>User ID: </label>
                        <td colspan="2">
                            <?php echo $student_id;?>
                            <input type="hidden" name="id" value="<?php echo $student_id;?>"maxlength="10"/>
                        </td>
                    </div>
                    </br>
                    <div class="z">
                        <label>User Name: </label>
                        <td colspan="2"><input type="text" id="student_name" name="student_name" value="<?php echo $student_name;?>"></td>
                    </div>
                    </br>
                    <div class="z">
                        <label>Email Address: </label>
                        <td colspan="2"><input type="text" id="student_name" name="email" value="<?php echo $email;?>"></td>
                    </div>  
                    </br>
                    <div class="z">
                        <label>Phone Number: </label>
                        <td colspan="2"><input type="text" id="student_name" name="phonenumber" value="<?php echo $phonenumber;?>"></td>
                    </div> 
                    </br>
                    <div class="z">
                        <label>Gender: </label>
                        <td colspan="2"><input type="text" id="student_name" name="gender" value="<?php echo $gender;?>"></td>
                    </div> 
                    </br>
                    <button type="submit"name="update">Update</button>
                    <button type="button"onclick="location='userinfo.php'">Back</button>
                </form>
        </fieldset>
        </div>
    </div>
    <body>
</html>
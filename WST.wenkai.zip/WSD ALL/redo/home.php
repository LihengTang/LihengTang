<html>
    <head>
        <meta charset="UTF-8"/>
        <link rel="stylesheet" href="headerfooter.css"/>
        <link rel="stylesheet" href="about_us.css"/>
        <link rel="stylesheet" href="latest.css"/>
        <title>Home Page</title>
        <style>
        h1
        {
            text-align:center;
        }
        img.p1jpg
        {
            width:600px;
            height:400px;
        }
        </style>
    </head>

    <body>
        <div class="right">
            <?php    
                include('header.php');
            ?>
        </div>
        <div class="left" width="80%">
            <div class="reservation">
                <a href="reservation.php"><img scr="reservation.jpg"alt=" "class="reservation"></a>
            </div>
            </br></br>
            <div class="event">
                <h1>Latest Events</h1>
                <table>
                    <tr>
                        <td>
                            <img src="p5.jpg" width="550px" height="450px" alt=""/>
                        </td>
                        <td>
                        <form method="post" action="register(A) form.php">
                            <div class="d">
                                <h2>*TARUMT CUP 5vs5(Perak Branch)</h2></br>
                                <p>Tarumt Cup are divided Male and Female.</p>
                                <p>-One Team at least 8 members(Must is TARUMT Student).</p>
                                <p>-At least 10 teams must be raised before the competition can be held.</p></br> 
                                <h2>Prize</h2>
                                <p>*The champion can get RM2500 cash + champion medal + soft skill mark (30 points per person).</p>
                                <p>*The runner-up can get RM1500 cash + runner-up medal + soft skill mark (20 points per person).</p>
                                <p>*The third runner-up can get RM500 cash + third runner-up medal + soft skill mark (10 points per person).</p>
                                <h4>If you are interested, please click here to register and fill in your information</h4>
                                <button type="submit">Register Now</button>
                            </div>
                        </form>
                        </td>
                    </tr>
                </table>
                </br>
                </br>
            </div>
            </br></br>
            <div class="announcement">
                <h1>Latest Announcements & Updates</h1>
                <table>
                    <tr>
                        <td>
                            <img class="p1jpg" src="p1.jpg" alt="">
                        </td>
                        <td>
                            <h2>Welcome Our New Coach !!!</h2> 
                            <div class="b">
                                <h3>- We are pleased to announce that Malaysian Development Basketball League MVP Qiu Jiahao will serve as our TARUMT basketball coach.</h3>
                                <h3>- Jiahao won the national championship in the Malaysian Development Basketball League last season, and recently represented Malaysia in the FIBA 3X3 Asia Cup, and brought a wealth of game experience to the club.</h3>
                                <h3>- He is very qualified to serve as tarumt's basketball academy coach.</h3>
                            </div>
                        </td>
                    </tr>
                </table>
                </br>
                </br>
            </div>
            </br></br>
            <div class="aboutus">
                <h1>About Us</h1>
                    <div id="word">
			        <p>The TARUMT Basketball Society is a group of individuals who share a common passion for basketball. 
			            The society is dedicated to promoting the sport, providing a platform for basketball players of all 
			            levels to come together and engage in the game, and developing skills and sportsmanship.
			        </p>
                    <p>The society was established with the goal of creating a community of individuals who love basketball 
			            and want to play it regularly. Members of the society come from diverse backgrounds, including students, 
			            working professionals, and basketball enthusiasts from various parts of the country.
                    </p>
			        <p>The society offers a wide range of activities, including regular basketball games, training sessions, 
			            and tournaments. Members are encouraged to participate in all activities, regardless of their skill level, 
			            as the society is focused on helping members improve their skills and develop their game.
                    </p>
			        <p>In addition to promoting the sport, the society places a strong emphasis on teamwork, sportsmanship, 
			            and community. Members are encouraged to work together as a team, support each other, and help build a strong 
			            and vibrant community around the sport.
			        </p>
                    <p>Overall, the TARUMT Basketball Society is a dynamic and passionate group of individuals who share a love 
			            for basketball. The society provides an excellent platform for individuals to engage with the sport, develop 
			            their skills, and build lasting relationships with like-minded individuals.
                    </p>
		            </div>
                </br>
                </br>
            </div>
        </div>
        <div class="footer">
            <p>TARUMT Basketball Society</p>
        </div>
    </body>
</html>
<?php
function detectsignupError()
{
    global $email,$username,$phone,$password1,$password2;

    $error = array();

    if($email==NULL)
    {
      $error['email']='Email Address is Required';
    }
    elseif(!filter_var($email, FILTER_VALIDATE_EMAIL))
    {
		$error['email']='Invalid Characters in Your Email';
	  }

    if($phone!=NULL)
    {
      if(!preg_match("/^[0][1]\d{1}\-\d*$/", $phone))
      {
		$error['phone']="Wrong Phone Number Format.";
      }
	  }
    if($username==NULL)
    {
		  $error['username']="Username is Required.";
	  }

  if($password1==NULL)
  {
		$error['username']="Password is required.";
	}
	elseif(strlen($password1) < 8)
  {
	  $error['password1']="Password Must At Least 10 Characters.";
  }

  if($password2==NULL)
  {
		$error['password2']="Enter Confirmed Password.";
	}
	elseif($password2 != $password1)
  {
		$error['password2']="Confirmed Password Must Same as First Password.";
  }
  return $error;
  }
?>
<html>
<head>
<meta charset="UTF-8">
<form method="post" action="home.php">
<script>
    function displaySuccess() {
        document.getElementById("success-message").style.display = "block";
      }
    </script>
</head>
<body>
<?php
if(isset($_POST['submit']))
{
  if(isset($_POST['phone'])){
		$phone=$_POST['phone'];
	}

  $email=trim($_POST['email']);
  $username=trim($_POST['username']);
  $password1=trim($_POST['password1']);
  $password2=trim($_POST['password2']);

  $error=detectsignupError();
  if (empty($error))
    {
      echo"<h1>Completed</h1>";
      echo'<div id="d">
      <img src="p4.png" width="300px" height="300px" alt=""/></div>';
      echo"<h2>Thank You For Your Sign Up Form Mr/Ms. $username<h2>";
      echo"<form>
      <button>Back to Home</button>        
      </form>";
    }
    else 
    {
      printf('
      <h1>THERE IS ERROR(s) IN THE SIGN UP FORM</h1>
      <ul><li class="error">%s</li></ul>
      <p><a href="javascript:history.back()">Back</a></p>
      ',implode('</li><li class="error">',$error));
    }

}
?>      

</body>
</html>
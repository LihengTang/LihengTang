<?php
require_once('connect.php');
?>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="headerfooter.css"/>
        <link rel="stylesheet" href="latest.css"/>
        <title>User Info</title>
        <style>
            table,th,td{

                border:1px solid black;
            }
        </style>
    </head>
    <body>
        <div class="whole">
            <?php    
                include('header(admin).php');
            ?>
            <div class="left">
            <div class ="event">
                <div>
                    <h1>Users</h1>
                </div>
                <div>
                    <table>
                        <tr>
                        <th>User ID</th>
                        <th>User Name</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>Gender</th>
                        <th>Tools</th>
                        </tr>
                        <?php
				$q = "SELECT * FROM user";
				$r = mysqli_query($connect,$q);
				$num = mysqli_num_rows($r);

				if ($num > 0)
				{
					while($row = mysqli_fetch_array($r))
					{
						printf
						('
							<tr>
								<td>'.$row['UserID'].'</td>
								<td>'.$row['Username'].'</td>
                                <td>'.$row['Email'].'</td>
								<td>'.$row['PhoneNumber'].'</td>
                                <td>'.$row['Gender'].'</td>
								<td align ="center">
									[<a href="edituser.php?id='.$row['UserID'].'">Edit</a>]
									|
									[<a href="delete.php?id='.$row['UserID'].'">Delete</a>]
								</td>
							</tr>
						');
					}
				}
				printf
				("
					<tr>
						<td colspan='6'>$num record(s) returned</td>
					</tr>

				");
				mysqli_free_result($r);
				mysqli_close($connect);
				?>
                    </table>
                    </br>
                    [<a href="insertnewuser.php">Insert New User</a>]
                    </br></br>
                </div>
            </div>
			<input type="submit" name="delete" value="Delete" 
onclick="return confirm('Are you sure to delete all the checked records?')"/>
</div class="left">
        </div>
        </div>
        <div class="footer">
            <p>TARUMT Basketball Society</p>
        </div>
    </body>
</html>
<html>
<?php require_once('connect.php'); ?>
    <head>
        <meta charset="UTF-8"/>
        <link rel="stylesheet" href="headerfooter.css"/>
        <link rel="stylesheet" href="about_us.css"/>
        <link rel="stylesheet" href="latest.css"/>
        <link rel="stylesheet" href="content.css"/>
        <title>Updates</title>
        <style>
.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: rgba(0,0,0,0.7);
  overflow-x: hidden;
  padding-top: 60px;
  text-align:center;
}
.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: white;
  display: block;
}
.sidenav a:hover{
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}
img.p1jpg
        {
            width:600px;
            height:400px;
        }
        </style>
    </head>

    <body>
        <div class="right">
            <?php    
                include('header(admin).php');
            ?>
        </div>
        <div class="left" width="80%">
            <div class="event">
                </br>
                [<a href="addannouncement.php">Insert New Announcement & Update</a>]
                <h1>Updates</h1>
                <table>
                    <tr>
                        <th>Title</th>
                        <th>More Information</th>
                        <th>Date</th>
                    </tr>
                    <?php
                        $user = '99';
                        $q = "SELECT * FROM announcement";
                        $r = @mysqli_query($connect,$q);
                        $show = @mysqli_num_rows($r);
                        while($row  = mysqli_fetch_array($r)){	
	                        printf('
                            <tr>
                                <td>
                                    '.$row['Title'].'
                                </td> 
                                <td>
                                    <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;Press Here</span>
                                    <div id="mySidenav" class="sidenav">
                                        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                                        <div class="event">
                                            <table>
                                                <tr>
                                                    <td>
                                                        <img src="'.$row['Image'].'.jpg"width="550px" height="450px">
                                                    </td>
                                                    <td>
                                                        <div class="d">'.$row['AnnouncementDesc'].'</div>
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </td>  
                                <td>'.$row['Dates'].'</td>
                                <td>[<a href="editannouncement.php">Edit</a>]</td>
                            </tr>');}
                    ?>
                </table>
				<input type="submit" name="delete" value="Delete" 
onclick="return confirm('Are you sure to delete all the checked records?')"/>
</div class="left">
            </div>
        </div>
        <div class="footer">
            <p>TARUMT Basketball Society</p>
        </div>
        <script>
function openNav() {
  document.getElementById("mySidenav").style.width = "100%";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
    </body>
</html>
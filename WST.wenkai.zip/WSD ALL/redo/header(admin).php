<nav class="right">
    <div class ="button">
        <div class="upper">
            <div>
                <a class="right"href="home(admin).php">
                    <img id="logo"src="logo.png" alt="Basketball Society">
                </a>
            </div>
            <br>
            <div class="rightinner">
                <a class="right"href="logout.php">LOG OUT</a>
            </div>
        </div>
        <div class="lower">
            <div class ="rightmiddle">
                <ul class="lower">
                    <li class="right">
                        <div class="rightinner">
                            <a class="right"href="home(admin).php">HOME</a>
                        </div>
                    </li>
                    <br>
                    <li class="right">
                        <div class="rightinner">
                            <a class="right"href="MyAccount(admin).php">MY ACCOUNT</a>
                        </div>
                    </li>
					<br>                            
                    <li class="right">    
                        <div class="rightinner">
                            <a class="right"href="list_leader.php">STAFF INFO</a>
                        </div> 
                    </li>
                    <br>                            
                    <li class="right">    
                        <div class="rightinner">
                            <a class="right"href="userinfo.php">USERS INFO</a>
                        </div> 
                    </li>
                    <br>
                    <li class="right">
                        <div class="rightinner">
                            <a class="right"href="reservationinfo.php">RESERVATIONS INFO</a>
                        </div> 
                    </li>
                    <br>
                    <li class="right">
                        <div class="rightinner">
                            <a class="right"href="events.php">EVENTS</a>
                        </div>
                    </li>
                    <br>
                    <li class="right">
                        <div class="rightinner">
                            <a class="right"href="announcements.php">ANNOUNCEMENTS & UPDATES</a>
                        </div>
                    </li>
                    <br>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php
require_once('con.php');

$staff_id = "";
$staff_name = "";
$gender = "";
$job_position = "";
$error = "";

if(!empty($_POST)) {
	$staff_id = strtoupper(trim($_POST['staff_id']));
	$staff_name = trim($_POST['staff_name']);
	if (isset($_POST['gender'])) {
		$gender = $_POST['gender'];
	}
	$job_position = $_POST['job_position'];
	
	$error = array();
	
	if($staff_id ==null) {
		$error['staff_id'] = 'Please enter the Staff ID.';
	}
	if($staff_name == null) {
		$error['staff_name'] = 'Please enter the Staff Name.';
	}
	if(!isset($_POST['gender'])) {
		$error['gender'] = 'Please enter the Gender.';
	}
	if($job_position == null) {
		$error['job_position'] = 'Please enter the Job Position.';
	}
	
	if (empty($error)) {
		$q = "INSERT INTO admin (staff_id,staff_name,gender,job_position)
		VALUES('$staff_id','$staff_name','$gender','$job_position')";
		$r = mysqli_query($condb, $q);
		
		if ($r) {
			echo "<p>The staff has been registered successful.</p>";
		} else {
			echo "<p>The staff cannot be registered succeddfully.</p>";
		}
		
		mySqli_close($condb);
	} else {
		echo "<ul class='a'>";
		foreach ($error as $value) {
			echo "<li>$value</li>";
		}
		echo "</ul>";
	}
}
?>

<html>
	<head>
	 <meta charset="UTF-8">
	 	        <link rel="stylesheet" href="headerfooter.css"/>
	<title>	Insert Staffs</title>
	
	<style>
			body{
				background-image:url("p13.jpg");
				margin-top:100px;
				margin-left:550px;
			}
			ul.a{
				list-style-type: none;
				background-color:black;
				width:250px;
				color:red;
				margin-left:100px;
				
			}
			h2{
				color:gray;
				background-color:black;
				width:150px;
				margin-left:200px;
				margin-top:100px;
				margin-right:750px;
			}
			table{
				margin-top:250px;
				margin-right:600px;
				width:550px;
				height:250px;
			}
			td{
				width:150px;
				heigth:20px;
			}
			input[type="text"]{
				width:450px;
				height:50px;
			}
			input[type=button]{
				color:white;
				background-color:black;
			}
    </style>
	
	</head>
	<body>
	<?php include('header(admin).php')?>
		
			<h2>Add Staff</h2>
			<center>
				<form action="insert_leader.php" method="POST">
				<table border="1">
				<tr>
					<td>Staff ID:</td>
					<td><input type="text" name="staff_id"
					value="<?php echo $staff_id; ?>" maxlength="10" /></td>
							
				<tr>
				
					<td>Staff Name:</td>
					<td><input type="text" name="staff_name"
					value="<?php echo $staff_name; ?>" maxlength="10" /></td>
				</tr>
				
				<tr>
				<td>Gender:</td>
				<td>
				Female<input type="radio" name="gender" value="Female"
				<?php if ($gender == 'F') echo "checked='checked'"; ?> />
				Male<input type="radio" name="gender" value="Male"
				<?php if ($gender == 'M') echo "checked='checked'"; ?> />
			</td>
			</tr>
				<tr>
					<td>Job Position:</td>
					<td><input type="text" name="job_position"
					value="<?php echo $job_position; ?>" maxlength="10" /></td>
							
				</tr>
				</table>
				<a href="list_leader.php">
				<input type="submit" name="submit" value="Insert">
				
				<input type="button" name="cancel" value="Back">
				</a>
				</form>
		</center>
	</body>
</html>
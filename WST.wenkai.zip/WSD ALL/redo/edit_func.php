
<?php
include 'con.php';
$row = $_GET['staff_id'];
?>


<?php 
    $staff_id = "";
    $staff_name = "";
    $gender = "";
    $job_position = "";

    if(isset($_POST['submit'])) {
        $staff_id = mysqli_real_escape_string($condb, $_POST['staff_id']);
        $staff_name = mysqli_real_escape_string($condb, $_POST['staff_name']);
        $gender = mysqli_real_escape_string($condb, $_POST['gender']);
        $job_position = mysqli_real_escape_string($condb, $_POST['job_position']);

        mysqli_query($condb,"UPDATE admin set staff_id='" . $_POST['staff_id'] . "', staff_name='" . $_POST['staff_name'] . "', gender='" . $_POST['gender'] . "', job_position='" . $_POST['job_position'] ."' WHERE staff_id='" . $row . "'");
		$message = "Record Modified Successfully";
    }
?>

<html>
<head>
<title>Update Questions</title>
</head>
<body>
<link rel= "stylesheet" href="#"> 
	<style>
		body{
			background-color:pink;
		}
		input[type="text"]{
			background-color:black;
			color:white;
		}


	</style>
	<br>
<center>	<br>
<form method="post" action="edit_func.php?staff_id=<?php echo $row ?>">
<div><?php if(isset($message)) { echo $message; } ?>
</div>
<div style="padding-bottom:5px;">

</div>
<?php
	$sql = "SELECT * FROM admin WHERE staff_id = $row";
    $result = mysqli_query($condb, $sql);
    $data = mysqli_fetch_array($result);
?>

<div class='box2'>
<input type="hidden" name="staff_id" class="txtField" value="<?php echo $data['staff_id']; ?>">

<h2>Update Questions</h2>
Staff ID:<br>
<input type="text" name="staff_id" class="txtField" value="<?php echo $data['staff_id']; ?>">
<br>
<br>

Staff Name: <br>
<input type="text" name="staff_name" class="txtField" value="<?php echo $data['staff_name']; ?>">
<br>
<br>

Gender:<br>
<input type="text" name="gender" class="txtField" value="<?php echo $data['gender']; ?>">
<br>
<br>

Job Position:<br>
<input type="text" name="job_position" class="txtField" value="<?php echo $data['job_position']; ?>">
<br>
<br>
<input type="submit" name="submit" value="Submit" >
<a href="list_leader.php">Cancel</a>
<a href="list_leader.php">Back</a>

</form>
<!--<a href="update.php?staff_id=' .$staff_id . '">-->
</div>
</body>
</html>
</center>






